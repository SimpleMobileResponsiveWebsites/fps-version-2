from .game import FPSGame

__all__ = ['FPSGame']